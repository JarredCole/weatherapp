# weatherapp
Weather using angular.js with a weather api from rapid api.com
