export const environment = {
    production: false,
    weatherApiBaseUrl: 'https://open-weather13.p.rapidapi.com/city',
    XRapidAPIHostLabelHeaderName: 'X-RapidAPI-Host',
    XRapidAPIHostLabelHeaderValue: 'open-weather13.p.rapidapi.com',
    XRapidAPIKeyHeaderName: 'X-RapidAPI-Key', 
    XRapidAPIKeyHeaderValue:
    '8159f02505mshb1b1030c7d78198p1f8e84jsn640c22bb4f1a'
};
